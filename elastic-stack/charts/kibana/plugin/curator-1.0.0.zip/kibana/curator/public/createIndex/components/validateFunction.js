/**
* Validates a cron expression.
*
* @param cronExpression The expression to validate
* @return True is expression is valid
*/
import parser from 'cron-parser';
import React from 'react';

export function getCronTime(cronExpress) {
  try {
    const newOrignData = new Array();
    const interval = parser.parseExpression(cronExpress);
    [1, 2, 3].forEach(function () {
      const d = new Date(interval.next().toString());
      const time = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate() + ' ' + d.getHours() + ':'
      + d.getMinutes() + ':' + d.getSeconds();
      newOrignData.push(time);
    });
    return (<div><p>{newOrignData[0]}</p><p>{newOrignData[1]}</p><p>{newOrignData[2]}</p></div>);
    //return newOrignData.join(' | ');
  } catch (error) {
    return 'cron is illegal!';
  }
}

export function validateCron(cronExpress) {
  try {
    parser.parseExpression(cronExpress);
    return true;
  } catch (error) {
    return false;
  }
}

export function validateTime(format) {
  const curdate = new Date();
  if (format === undefined || format === '') return false;
  format = format.replace(/YYYY/i, curdate.getFullYear());
  format = format.replace(/MM/i, fix2number(curdate.getMonth() + 1));
  format = format.replace(/DD/i, fix2number(curdate.getDate()));
  format = format.replace(/yyyy/i, curdate.getFullYear());
  format = format.replace(/mm/i, fix2number(curdate.getMonth() + 1));
  format = format.replace(/dd/i, fix2number(curdate.getDate()));
  const reg = /[A-Za-z]+/;
  const res = reg.test(format);
  if(res) {
    return false;
  }else{
    return true;
  }
}

function fix2number(n)
{
  return [0, n].join('').slice(-2);
}

