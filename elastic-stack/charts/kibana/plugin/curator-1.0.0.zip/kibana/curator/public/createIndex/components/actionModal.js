/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import React, { Component } from 'react';
import {
  EuiButtonIcon,
  EuiConfirmModal,
  EuiOverlayMask,
  EUI_MODAL_CONFIRM_BUTTON,
  EuiButton,
  EuiButtonEmpty,
  EuiFieldText,
  EuiForm,
  EuiFormRow,
  EuiModal,
  EuiModalBody,
  EuiModalFooter,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiSelect,
  EuiFlexGroup,
  EuiFlexItem,
  EuiIconTip,
} from '@elastic/eui';
import axios from 'axios';
axios.defaults.headers.post['kbn-xsrf'] = 'reporting';
import * as validateFunction from './validateFunction';

export class ActionModal extends Component {
  constructor(props) {
    super(props);
    this.showDestroyModal = this.showDestroyModal.bind(this);
    this.closeDestroyModal = this.closeDestroyModal.bind(this);
    this.showUpdateModal = this.showUpdateModal.bind(this);
    this.closeUpdateModal = this.closeUpdateModal.bind(this);
    this.deleteIndex = this.deleteIndex.bind(this);
    this.onIndexChange = this.onIndexChange.bind(this);
    this.onCreateTimeChange = this.onCreateTimeChange.bind(this);
    this.onActionChange = this.onActionChange.bind(this);
    this.initEditPageValue = this.initEditPageValue.bind(this);
    this.submit = this.submit.bind(this);
    this.state = {
      errors: [],
      isDestroyModalVisible: false,
      isUpdateModalVisible: false,
    };
  }


  initEditPageValue() {
    const indicesObj = this.props.indicesObj;
    this.setState({
      indexName: indicesObj == null ? null : indicesObj.indexName,
      indexId: indicesObj == null ? null : indicesObj.indexId,
      createTime: indicesObj == null ? null : indicesObj.createTime,
      action: indicesObj == null ? null : indicesObj.action,
      createTimeHelp: validateFunction.getCronTime(indicesObj.createTime),
      isInvalid: false,
    });
  }

  onActionChange = e => {
    this.setState({
      action: e.target.value,
    });
  };
  onIndexChange = e => {
    this.setState({
      indexName: e.target.value,
    });
  };
  onCreateTimeChange = e => {
    this.setState({
      createTime: e.target.value,
      createTimeHelp: validateFunction.getCronTime(e.target.value),
    });
  };
  //删除操作
  async deleteIndex() {
    const response = await axios.post('../api/curator/createindex/delete', { id: this.props.indicesObj.indexId });
    if(response.status === 200 || response.statusText === 'OK') {
      this.setState({ isDestroyModalVisible: false });
      this.props.showToast({
        title: 'Delete index success!',
        color: 'success',
        id: Date.parse(new Date()),
      });
    } else {
      this.props.showToast({
        title: 'Oops, there was an error',
        color: 'danger',
        iconType: 'help',
        id: Date.parse(new Date()),
        text: (
          <p>
            Could not Delete autoCreateIndex!
          </p>
        ),
      });
      console.error(response);
    }
    this.props.queryCreateIndices();
  }

  //保存
  async submit() {
    if(this.state.indexName === '' || this.state.createTime === '') {
      this.setState({
        isInvalid: true,
        errors: ['input is empty,please check!']
      });
    } else {
      try {
        let name = new Array();
        name = this.state.indexName.split('[');
        if(name.length >= 2) {
          const timeFormat = name[1].replace(']', '').toUpperCase();
          if(validateFunction.validateTime(timeFormat)) {
            //验证Cron
            if(validateFunction.validateCron(this.state.createTime)) {
              const response = await axios.post('../api/curator/createindex/index', {
                indexName: this.state.indexName,
                createTime: this.state.createTime,
                action: this.state.action,
                id: this.state.indexId,
                timestamp: new Date().getTime()
              });
              if(response.status === 200 || response.statusText === 'OK') {
                this.setState({ isAddIndex: false });
                this.props.showToast({
                  title: 'Create autoCreateIndex settings success!',
                  color: 'success',
                  id: Date.parse(new Date()),
                });
                this.props.queryCreateIndices();
              } else {
                this.setState({
                  isInvalid: true,
                  errors: ['Could not Update autoCreateIndex!,please check Input!',
                    'indexName should like index-[yyyy.mm.dd]',
                    'Cron should like 0 0 14 * * ?']
                });
              }
            }
            else {
              this.setState({
                isInvalid: true,
                errors: ['Could not Update autoCreateIndex!,please check Cron!',
                  'Cron should like 0 0 14 * * ?']
              });
            }
          }
          else {
            this.setState({
              isInvalid: true,
              errors: ['Could not Update autoCreateIndex!,please check index!',
                'indexName should like index-[yyyy.mm.dd]']
            });
          }
        } else {
          this.setState({
            isInvalid: true,
            errors: ['Could not Update autoCreateIndex!,please check Input!',
              'indexName should like index-[yyyy.mm.dd]']
          });
        }
      } catch (error) {
        this.setState({
          isInvalid: true,
          errors: ['input is illegal,please check Input!',
            'indexName should like index-[yyyy.mm.dd]',
            'Cron should like 0 0 14 * * ?']
        });
      }
    }
  }

  closeDestroyModal() {
    this.setState({
      isInvalid: false,
      isDestroyModalVisible: false
    });
  }
  showDestroyModal() {
    this.setState({ isDestroyModalVisible: true });
  }
  closeUpdateModal() {
    this.setState({ isUpdateModalVisible: false });
  }
  showUpdateModal() {
    this.initEditPageValue();
    this.setState({
      isUpdateModalVisible: true
    });
  }

  render() {
    const formSample = (
      <EuiForm error={this.state.errors} isInvalid={this.state.isInvalid}>
        <EuiFlexGroup>
          <EuiFlexItem grow={false} style={{ width: 400 }}>
            <EuiFormRow label="Index Name">
              <EuiFieldText name="indexName" value={this.state.indexName} onChange={this.onIndexChange} placeholder="index-[yyyy.mm.dd]"/>
            </EuiFormRow>
          </EuiFlexItem>
        </EuiFlexGroup>
        <EuiFlexGroup>
          <EuiFlexItem grow={false} style={{ width: 400 }}>
            <EuiFormRow label="Action">
              <EuiSelect
                options={[{ value: 'autoCreateIndex', text: 'Auto Create Index' }]}
                defaultValue={this.state.action}
                onChange={this.onActionChange}
              />
            </EuiFormRow>
          </EuiFlexItem>
        </EuiFlexGroup>
        <EuiFlexGroup>
          <EuiFlexItem grow={false} style={{ width: 400 }}>
            <EuiFormRow label="Cron" isInvalid={this.state.isInvalid}>
              <EuiFieldText name="createTime" value={this.state.createTime} placeholder="0 0 14 * * ?" onChange={this.onCreateTimeChange}/>
            </EuiFormRow>
          </EuiFlexItem>
          <EuiFlexItem grow={false}>
            <EuiFormRow hasEmptyLabelSpace>
              <EuiIconTip
                content={this.state.createTimeHelp}
                position="right"
                color="#0079A5"
              />
            </EuiFormRow>
          </EuiFlexItem>
        </EuiFlexGroup>
      </EuiForm>
    );

    let destroyModal;
    //删除确认框
    if(this.state.isDestroyModalVisible) {
      destroyModal = (
        <EuiOverlayMask>
          <EuiConfirmModal
            title="Do this destructive thing"
            onCancel={this.closeDestroyModal}
            onConfirm={this.deleteIndex}
            cancelButtonText="Cancel"
            confirmButtonText="Delete"
            buttonColor="danger"
            defaultFocusedButton={EUI_MODAL_CONFIRM_BUTTON}
          >
            <p>You&rsquo;re want to delete this aotuCreateIndex</p>
            <p>Are you sure you want to do this?</p>
          </EuiConfirmModal>
        </EuiOverlayMask>
      );
    }

    if(this.state.isUpdateModalVisible) {
      destroyModal = (
        <EuiOverlayMask>
          <EuiModal onClose={this.closeUpdateModal} style={{ width: '600px' }}>
            <EuiModalHeader>
              <EuiModalHeaderTitle>Update</EuiModalHeaderTitle>
            </EuiModalHeader>
            <EuiModalBody>{formSample}</EuiModalBody>
            <EuiModalFooter>
              <EuiButtonEmpty onClick={this.closeUpdateModal}>Cancel</EuiButtonEmpty>
              <EuiButton onClick={this.submit} fill>
                    Save
              </EuiButton>
            </EuiModalFooter>
          </EuiModal>
        </EuiOverlayMask>
      );
    }


    return(
      <div>
        <EuiButtonIcon
          size="s"
          onClick={this.showUpdateModal}
          iconType="pencil"
          aria-label="Edit"
        />
        &nbsp;&nbsp;&nbsp;&nbsp;
        <EuiButtonIcon
          size="s"
          onClick={this.showDestroyModal}
          iconType="trash"
          aria-label="Delete"
          color="danger"
        />
        {destroyModal}
      </div>
    );
  }
}