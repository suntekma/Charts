/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import React, {
  Component,
  Fragment
} from 'react';

import {
  EuiButton,
  EuiInMemoryTable,
  EuiSpacer,
  EuiFlexGroup,
  EuiGlobalToastList,
  EuiOverlayMask,
  EuiButtonEmpty,
  EuiFieldText,
  EuiForm,
  EuiFormRow,
  EuiModal,
  EuiModalBody,
  EuiModalFooter,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiSelect,
  EuiFlexItem,
  EuiIconTip,
} from '@elastic/eui';
import axios from 'axios';
import { ActionModal } from './actionModal';
import * as validateFunction from './validateFunction';
class IndicesObj {
  constructor(indexName, indexId, createTime, action, timestamp) {
    this.indexName = indexName;
    this.indexId = indexId;
    this.createTime = createTime;
    this.action = action;
    this.timestamp = timestamp;
  }
}
let debounceTimeoutId;
let requestTimeoutId;

export default class Table extends Component {
  constructor(props) {
    super(props);
    this.queryCreateIndices = this.queryCreateIndices.bind(this);
    this.showToast = this.showToast.bind(this);
    this.removeToast = this.removeToast.bind(this);
    this.onIndexChange = this.onIndexChange.bind(this);
    this.onCreateTimeChange = this.onCreateTimeChange.bind(this);
    this.onActionChange = this.onActionChange.bind(this);
    this.closeAddIndexModal = this.closeAddIndexModal.bind(this);
    this.showAddIndexModal = this.showAddIndexModal.bind(this);
    this.saveIndex = this.saveIndex.bind(this);
    this.initAddPageValue = this.initAddPageValue.bind(this);
    this.compare = this.compare.bind(this);
    const store = [];
    this.state = {
      isLoading: true,
      store: store,
      toasts: [],
      error: [],
      indices: [],
    };
  }

  initAddPageValue() {
    this.setState({
      indexName: '',
      indexId: '',
      createTime: '',
      action: 'autoCreateIndex',
      createTimeHelp: 'Please Input Cron',
      isInvalid: false,
    });
  }

  componentDidMount() {
    this.queryCreateIndices();
  }

  showToast(toast) {
    this.setState({ toasts: this.state.toasts.concat(toast), });
  }
  removeToast = (removedToast) => {
    this.setState(prevState => ({
      toasts: prevState.toasts.filter(toast => toast.id !== removedToast.id),
    }));
  };

  //查询数据
  async queryCreateIndices() {
    this.setState({
      isLoading: true,
    });
    //使用axios获取数据
    let indices = [];
    let store = [];
    try {
      const { data } = await axios('../api/curator/createindex/search');
      if(data.hits.total > 0) {
        indices = data.hits.hits;
        store = this.reBuildOriginData(indices);
      }
    } catch (error) {
      console.error(error);
    }
    this.setState({
      store: store,
      indices: indices,
      isLoading: false,
      isAddIndex: false,
      action: 'autoCreateIndex',
    });
  }
  /**`
   * 构建页面展示所需要格式数据
   * @param {*} orignData
   */
  reBuildOriginData(indices) {
    const newOrignData = new Array();
    for(const index in indices) {
      if(indices.hasOwnProperty(index)) {
        const obj = indices[index]._source;
        const indicesObj = new IndicesObj(obj.indexName, indices[index]._id, obj.createTime, obj.action, obj.timestamp);
        newOrignData.push(indicesObj);
      }
    }
    return newOrignData.sort(this.compare('timestamp'));
  }
  compare(property) {
    return function (obj1, obj2) {
      return obj2[property] - obj1[property];
    };
  }

  async saveIndex() {
    if(this.state.indexName === '' || this.state.createTime === '') {
      this.setState({
        isInvalid: true,
        errors: ['input is empty,please check!']
      },
      );
    } else {
      try {
        let name = new Array();
        name = this.state.indexName.split('[');
        if(name.length >= 2) {
          const timeFormat = name[1].replace(']', '').toUpperCase();
          console.log('timeFormat' + timeFormat);
          console.log('timeFormat:' + validateFunction.validateTime(timeFormat));
          if(validateFunction.validateTime(timeFormat)) {
            //验证Cron
            console.log('Cron:' + validateFunction.validateCron(this.state.createTime));
            if(validateFunction.validateCron(this.state.createTime)) {
              const response = await axios.post('../api/curator/createindex/index', {
                indexName: this.state.indexName,
                createTime: this.state.createTime,
                action: this.state.action,
                id: this.state.indexId,
                timestamp: new Date().getTime()
              });
              if(response.status === 200 || response.statusText === 'OK') {
                this.setState({ isAddIndex: false });
                this.showToast({
                  title: 'Create autoCreateIndex settings success!',
                  color: 'success',
                  id: Date.parse(new Date()),
                });
                this.queryCreateIndices();
              } else {
                this.setState({
                  isInvalid: true,
                  errors: ['Could not Update autoCreateIndex!,please check Input!',
                    'indexName should like index-[yyyy.mm.dd]',
                    'Cron should like 0 0 14 * * ?']
                });
                console.error(response);
              }
            }
            else {
              this.setState({
                isInvalid: true,
                errors: ['Could not Update autoCreateIndex!,please check Cron!',
                  'Cron should like 0 0 14 * * ?']
              });
            }
          }
          else {
            this.setState({
              isInvalid: true,
              errors: ['Could not Update autoCreateIndex!,please check index!',
                'indexName should like index-[yyyy.mm.dd]']
            });
          }
        } else {
          this.setState({
            isInvalid: true,
            errors: ['Could not Update autoCreateIndex!,please check Input!',
              'indexName should like index-[yyyy.mm.dd]']
          });
        }
      } catch (error) {
        this.setState({
          isInvalid: true,
          errors: ['input is illegal,please check Input!',
            'indexName should like index-[yyyy.mm.dd]',
            'Cron should like 0 0 14 * * ?']
        });
      }
    }
  }

  renderToolsRight() {
    return [
      (<EuiButton onClick={this.showAddIndexModal} >Add</EuiButton>)];
  }


  closeAddIndexModal() {
    this.setState({
      isAddIndex: false,
    });
  }
  showAddIndexModal() {
    this.setState({
      isAddIndex: true,
    });
    this.initAddPageValue();
  }
  onActionChange = e => {
    this.setState({
      action: e.target.value,
    });
  };
  onIndexChange = e => {
    this.setState({
      indexName: e.target.value,
    });
  };
  onCreateTimeChange = e => {
    this.setState({
      createTime: e.target.value,
      createTimeHelp: validateFunction.getCronTime(e.target.value),
    });
  };
  onQueryChange = ({ query }) => {
    clearTimeout(debounceTimeoutId);
    clearTimeout(requestTimeoutId);
    debounceTimeoutId = setTimeout(() => {
      this.setState({
        isLoading: true,
      });
      const store = this.reBuildOriginData(this.state.indices);
      requestTimeoutId = setTimeout(() => {
        const indicesObjs = store.filter(indicesObj => {
          const normalizedName = `${indicesObj.indexName}`.toLowerCase();
          const normalizedQuery = query.text.toLowerCase();
          return normalizedName.indexOf(normalizedQuery) !== -1;
        });
        this.setState({
          isLoading: false,
          store: indicesObjs,
        });
      }, 1000);
    }, 300);
  }

  render() {
    const columns = [{
      field: 'indexName',
      name: 'Index Prefix',
      sortable: true,
      truncateText: true,
    }, {
      field: 'createTime',
      name: 'Cron',
    }, {
      field: 'action',
      name: 'Action'
    }, {
      filed: 'indexId',
      name: 'Operation',
      render: (indicesObj) => {
        return (
          <div>
            <ActionModal indicesObj={indicesObj} queryCreateIndices={this.queryCreateIndices} showToast={this.showToast}/>
          </div>
        );
      }
    }];

    const search = {
      onChange: this.onQueryChange,
      box: {
        incremental: true
      },
      toolsRight: this.renderToolsRight()
    };


    let addPage;
    if(this.state.isAddIndex) {
      const formSample = (
        <EuiForm error={this.state.errors} isInvalid={this.state.isInvalid}>
          <EuiFlexGroup>
            <EuiFlexItem grow={false} style={{ width: 400 }}>
              <EuiFormRow label="Index Name">
                <EuiFieldText name="indexName" onChange={this.onIndexChange} placeholder="index-[yyyy.mm.dd]"/>
              </EuiFormRow>
            </EuiFlexItem>
          </EuiFlexGroup>
          <EuiFlexGroup>
            <EuiFlexItem grow={false} style={{ width: 400 }}>
              <EuiFormRow label="Action">
                <EuiSelect
                  options={[{ value: 'autoCreateIndex', text: 'Auto Create Index' }]}
                  defaultValue={this.state.action}
                  onChange={this.onActionChange}
                />
              </EuiFormRow>
            </EuiFlexItem>
          </EuiFlexGroup>
          <EuiFlexGroup>
            <EuiFlexItem grow={false} style={{ width: 400 }}>
              <EuiFormRow label="Cron" isInvalid={this.state.isInvalid}>
                <EuiFieldText name="createTime" placeholder="0 0 14 * * ?" onChange={this.onCreateTimeChange}/>
              </EuiFormRow>
            </EuiFlexItem>
            <EuiFlexItem grow={false}>
              <EuiFormRow hasEmptyLabelSpace>
                <EuiIconTip
                  content={this.state.createTimeHelp}
                  position="right"
                  color="#0079A5"
                />
              </EuiFormRow>
            </EuiFlexItem>
          </EuiFlexGroup>
        </EuiForm>
      );

      addPage = (
        <EuiOverlayMask>
          <EuiModal onClose={this.closeAddIndexModal} style={{ width: '600px' }}>
            <EuiModalHeader>
              <EuiModalHeaderTitle>Add</EuiModalHeaderTitle>
            </EuiModalHeader>
            <EuiModalBody>{formSample}</EuiModalBody>
            <EuiModalFooter>
              <EuiButtonEmpty onClick={this.closeAddIndexModal}>Cancel</EuiButtonEmpty>
              <EuiButton onClick={this.saveIndex} fill>
                    Save
              </EuiButton>
            </EuiModalFooter>
          </EuiModal>
        </EuiOverlayMask>
      );
    }
    const page = (
      <Fragment>
        <EuiFlexGroup/>
        <EuiSpacer size="l"/>
        <EuiInMemoryTable
          items={this.state.store}
          loading={this.state.isLoading}
          columns={columns}
          search={search}
          pagination={true}
        />
      </Fragment>
    );
    return (
      <div>
        { page }
        <EuiGlobalToastList
          toasts={this.state.toasts}
          dismissToast={this.removeToast}
          toastLifeTimeMs={5000}
        />
        { addPage }
      </div>
    );
  }
}