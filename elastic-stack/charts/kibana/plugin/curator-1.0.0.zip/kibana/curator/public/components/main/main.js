import React from 'react';
import Cleaner from './../../cleaner/cleaner';
import IndicesView from './../../indicesView/indicesView'
import Create from './../../createIndex/createIndex'
import {
  EuiPage,
  EuiPageBody,
  EuiPageContent,
  EuiCard,
  EuiIcon,
  EuiFlexGroup,
  EuiBreadcrumbs,
  EuiSpacer,
  EuiFlexItem
} from '@elastic/eui';

export class Main extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pageLocation: 'home'
    };
  }

  componentDidMount() {}
  changeLocation = (page) => {
    this.setState({pageLocation: page});
  }

  render() {
    let page = {};
    let breadcrumbs = [];

    if (this.state.pageLocation == 'view') {
      breadcrumbs=[
        {
          text: 'Newegg Curator Home',
          href: '#',
          onClick: () => this.changeLocation('home'),
        },
        {
          text: 'Indices View',
          href: '#',
          onClick: () => this.changeLocation('view'),
        }
      ];
      page = <IndicesView/>;
    } else if (this.state.pageLocation == 'cleaner') {
      breadcrumbs=[
        {
          text: 'Newegg Curator Home',
          href: '#',
          onClick: () => this.changeLocation('home'),
        },
        {
          text: 'Cleaner',
          href: '#',
          onClick: () => this.changeLocation('cleaner'),
        }
      ];
      page = <Cleaner/>
    } else if(this.state.pageLocation == 'create'){
      breadcrumbs=[
        {
          text: 'Newegg Curator Home',
          href: '#',
          onClick: () => this.changeLocation('home'),
        },
        {
          text: 'Create',
          href: '#',
          onClick: () => this.changeLocation('create'),
        }
      ];
      page = <Create/>
    }else{
      breadcrumbs=[
        {
          text: 'Newegg Curator Home',
          href: '#',
          onClick: () => this.changeLocation('home'),
        }
      ];
      page = <EuiFlexGroup gutterSize="l">
        <EuiFlexItem key={`indices_view`}>
          <EuiCard
            icon={< EuiIcon color = 'primary' size = "xxl" type = {
            `editorUnorderedList`
          } />}
            title={`Indices view`}
            description="An awesome kibana plugin for view indies!"
            onClick={() => this.changeLocation('view')}/>
        </EuiFlexItem>
        <EuiFlexItem key={`cleaner`}>
          <EuiCard
            icon={< EuiIcon color = 'danger' size = "xxl" type = {
            `broom`
          } />}
            title={`Cleaner`}
            description="An awesome Kibana plugin for setting elasticsearch index ttl!"
            onClick={() => this.changeLocation('cleaner')}/>
        </EuiFlexItem>
        <EuiFlexItem key={`Create`}>
          <EuiCard
            icon={< EuiIcon size = "xxl" type = {
            `createSingleMetricJob`
          } />}
            title={`Indices create`}
            description="An awesome kibana plugin for view indies!"
            onClick={() =>  this.changeLocation('create')}/>
        </EuiFlexItem>
      </EuiFlexGroup>
    }
    return (
      <div>
        <EuiPage>
          <EuiPageBody>
          <EuiBreadcrumbs breadcrumbs={breadcrumbs} responsive={false} truncate={false} />
          <EuiSpacer size="xs" />
            <EuiPageContent >
              {page}
            </EuiPageContent>
          </EuiPageBody>
        </EuiPage>
      </div>
    );
  }
}
