
import  * as scheduleModuel from '../createscheduleJob';
const CLEANER_INDEX = '.cleaner';
const CLEANER_TYPE = 'ttl';
const CREATE_INDEX = '.auto_create_index';
const CREATE_TYPE = '_doc';
export default function (server, client) {
  server.route({
    path: '/api/curator/indices_view/_stats',
    method: 'GET',
    handler(req, reply) {
      client
        .indices
        .stats({
          human: false,
          level: 'indices',
          metric: ['docs', 'store', 'get', 'search', 'query_cache']
        }, function (err, response) {
          reply(response);
        });
    }
  });

  server.route({
    path: '/api/curator/cleaner/_stats',
    method: 'GET',
    handler(req, reply) {
      client
        .indices
        .stats({
          human: false,
          level: 'indices',
          metric: ['docs', 'store']
        }, function (err, response) {
          reply(response);
        });
    }
  });

  server.route({
    path: '/api/curator/cleaner/list',
    method: 'GET',
    handler(req, reply) {
      client
        .count({
          index: CLEANER_INDEX
        }, function (error, response) {
          client
            .search({
              index: CLEANER_INDEX,
              size: response.count
            }, function (err, response) {
              reply(response);
            });
        });

    }
  });

  server.route({
    path: '/api/curator/cleaner/index',
    method: 'POST',
    handler(req, reply) {
      const documentData = req.payload;
      client.index({
        index: CLEANER_INDEX,
        type: CLEANER_TYPE,
        id: documentData.id,
        refresh: 'wait_for',
        body: {
          // put the partial document under the `doc` key
          type: documentData.type,
          ttl: documentData.ttl
        }
      }, function (err, response) {
        reply(response);
      });
    }
  });

  server.route({
    path: '/api/curator/cleaner/delete',
    method: 'POST',
    handler(req, reply) {
      client
        .delete({
          index: CLEANER_INDEX,
          type: CLEANER_TYPE,
          refresh: 'wait_for',
          id: req.payload.id
        }, function (err, response) {
          reply(response);
        });
    }
  });
  //查询index
  server.route({
    path: '/api/curator/createindex/search',
    method: 'GET',
    handler(req, reply) {
      client.count({
        index: CREATE_INDEX, type: CREATE_TYPE
      }, function (err, response) {
        client.search({
          index: CREATE_INDEX, type: CREATE_TYPE,
          size: response.count
        }, function (err, response) {
          reply(
            response
          );
        });
      });
    }
  });



  //插入 更新
  server.route({
    path: '/api/curator/createindex/index',
    method: 'POST',
    handler(req, reply) {
      client.index({
        index: CREATE_INDEX,
        type: CREATE_TYPE,
        refresh: 'wait_for',
        id: req.payload.id,
        body: {
          indexName: req.payload.indexName,
          createTime: req.payload.createTime,
          action: req.payload.action,
          timestamp: req.payload.timestamp
        }
      }, function (err, response) {
        if(response.result === 'created') {
          scheduleModuel.create(req.payload.indexName, req.payload.createTime, req.payload.action,
            response._id, server);
        }
        if(response.result === 'updated') {
          scheduleModuel.cancel(response._id, server);
          scheduleModuel.create(req.payload.indexName, req.payload.createTime, req.payload.action,
            response._id, server);
        }
        reply(
          response
        );
      });

    }
  });

  //删除
  server.route({
    path: '/api/curator/createindex/delete',
    method: 'POST',
    handler(req, reply) {
      client.delete({
        index: CREATE_INDEX,
        type: CREATE_TYPE,
        refresh: 'wait_for',
        id: req.payload.id
      }, function (err, response) {
        if(response.result === 'deleted') {
          scheduleModuel.cancel(req.payload.id, server);
        }
        reply(
          response
        );
      });
    }
  });
}
