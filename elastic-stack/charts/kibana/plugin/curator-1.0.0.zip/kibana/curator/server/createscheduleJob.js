import schedule from 'node-schedule';
import moment from 'moment';
const INDEX = '.auto_create_index';
const cronExpress = '0 0 11 * * ?';
let client = null;

function  getScheduleJobs(server) {
  schedule.scheduleJob(cronExpress, function () {
    scheduledRun(server);
  });

}
/*jshint loopfunc: true */
async function scheduledRun(server) {
  const {
    count
  } = await client.count({
    index: INDEX
  });
  if(count > 0) {
    const {
      hits
    } = await client.search({
      index: INDEX,
      size: count
    });
    const data = hits.hits;
    for(const key in data) {
      if ({}.hasOwnProperty.call(data, key)) {
        const  action = data[key]._source.action;
        const cron = data[key]._source.createTime;
        let name = new Array();
        const  indexname = data[key]._source.indexName;
        name  = indexname.split('[');
        if(name.length >= 2) {
          const indexName = name[0];
          const timeFormat = name[1].replace(']', '').toUpperCase();
          const jobId = data[key]._id;
          if(action === 'autoCreateIndex') {
            if(!schedule.scheduledJobs[jobId]) {
              schedule.scheduleJob(jobId, cron, async function () {
                callBack(timeFormat, indexName, server);
              });
            }
          }
        }
      }

    }
  }

}

async function callBack(timeFormat, indexName, server) {
  const date = moment().add(1, 'days').format(timeFormat);
  const indexs = indexName + date;
  const response = await client.indices.exists({
    index: indexs.toLowerCase()
  });
  if(!response) {
    await client.indices.create({
      index: indexs.toLowerCase()
    });
    server.log(['info', 'create'], indexs + ':create success');
  }

}

export async function runJobs(server, esClient) {
  client = esClient;
  await init(server);
  scheduledRun(server);
  getScheduleJobs(server);
}

function init(server) {
  return new Promise(async function (resolve) {
    try{
      const response = await client.indices.exists({
        index: INDEX.toLowerCase()
      });
      if(!response) {
        const rep = await client.indices.create({
          index: INDEX.toLowerCase()
        });
        if(rep) {
          server.log(['info', 'create'], 'init index created ');
        }
      }
      resolve(true);
    }catch(error) {
      server.error('init index create faild!', error);
      resolve(false);
    }

  });

}

export async function create(indexName, cron, type, id, server) {
  if(type === 'autoCreateIndex') {
    if(!schedule.scheduledJobs[id]) {
      let name = new Array();
      name =  indexName.split('[');
      if(name.length >= 2) {
        const timeFormat = name[1].replace(']', '').toUpperCase();
        const index = name[0];
        schedule.scheduleJob(id, cron, async function () {
          callBack(timeFormat, index, server);
        });
        server.log(['info', 'create'], 'job add success');
      }
    }else{
      server.log(['debug', 'create'], 'job already create!');
    }
  }
}

export  function cancel(jobId, server) {
  if(schedule.scheduledJobs[jobId]) {
    const result = schedule.cancelJob(jobId);
    if(result) {
      server.log(['info', 'create'], 'remove success');
    }else{
      server.log(['debug', 'create'], 'remove faild');
    }
  }else{
    server.log(['debug', 'create'], 'job is always not exist');
  }

}

