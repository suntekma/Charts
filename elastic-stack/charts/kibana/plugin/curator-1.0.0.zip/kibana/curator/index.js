const elasticsearch = require('elasticsearch');
import serverRoute from './server/routes/serverRoute';
import * as scheduleModuel from './server/scheduleJob';
import * as createscheduleModuel from './server/createscheduleJob';
export default function (kibana) {
  return new kibana.Plugin({
    require: ['elasticsearch'],
    name: 'curator',
    uiExports: {
      app: {
        title: 'Curator',
        description: 'An awesome Kibana plugin for manager,view index ..',
        main: 'plugins/curator/app',
        icon: 'plugins/curator/curator.svg',
        styleSheetPath: require('path').resolve(__dirname, 'public/app.scss'),
      },
      injectDefaultVars: function (server) {
        const config = server.config();
        const pattern = config.get('curator.mergePattern');
        return {
          mergePattern: pattern,
        };
      }
    },

    config(Joi) {
      return Joi.object({
        enabled: Joi.boolean().default(true),
        scheduleTime: Joi.number().default(60),
        mergePattern: Joi.string().default('[^a-z]+$'),
      }).default();
    },

    init(server, options) { // eslint-disable-line no-unused-vars
      // Add server routes and initialize the plugin here
      const config = server.config();
      const client = new elasticsearch.Client({
        host: config.get('elasticsearch.url'),
        //log: 'trace'
        requestTimeout: 120000
      });
      serverRoute(server, client);
      const scheduleTime = server.config().get('curator.scheduleTime');
      scheduleModuel.run(scheduleTime, server, client);
      createscheduleModuel.runJobs(server, client);
    }
  });
}
